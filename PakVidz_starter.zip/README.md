# PakVidz (Flutter)

PakVidz – Pakistan's trending short video community.

## App IDs
- **Android applicationId**: `www.pakvidsapp.com.pk`
- **iOS bundleId**: `www.pakvidsapp.com.pk`

## Features in this scaffold
- TikTok-style vertical video feed (dummy videos from network)
- Like / Comment / Share / Favorite buttons
- Firebase ready (just add your configs)
- Earnings system scaffolding
- Live streaming gate (UI placeholder, unlock at 5K followers)
- Clean UI/UX (Material 3)

## Quick Start

1. Install Flutter SDK and Dart.
2. In this folder run:
   ```bash
   flutter pub get
   ```
3. **Firebase**: Create a Firebase project `PakVidz` and add Android/iOS apps with the same IDs above.
   - Download `google-services.json` into `android/app/`
   - Download `GoogleService-Info.plist` into `ios/Runner/`
4. **Keystore (release signing)**:
   ```bash
   # Create keystore (adjust passwords)
   keytool -genkey -v -keystore android/keystore/pakvidz-release.jks -storepass CHANGE_ME_STORE_PASS -alias pakvidz -keypass CHANGE_ME_KEY_PASS -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=PakVidz, OU=Dev, O=PakVidz, L=Karachi, S=Sindh, C=PK"
   # (Windows: use keytool from your installed Java JDK bin folder)
   ```
   Update passwords in `android/key.properties`.

5. **Build AAB**:
   ```bash
   flutter build appbundle --release
   ```
   Output: `build/app/outputs/bundle/release/app-release.aab`

6. **Play Console assets**
   - App Icon provided in `assets/icon/app_icon.png`
   - Short desc: *Watch, create, and share amazing short videos with PakVidz – Pakistan's trending video community.*
   - Full desc included below in this README.

## Descriptions
**Short Description**
> Watch, create, and share amazing short videos with PakVidz – Pakistan's trending video community.

**Full Description**
> PakVidz is Pakistan’s own short video platform where you can watch, create, and share amazing moments. Scroll through endless videos, connect with creators, and become part of a growing community.

**Feature List**
- Smooth vertical video scrolling
- Like, comment, share, and save favorites
- Live streaming (unlocked at 5K followers)
- Creator earning system (scaffolded)
- Easy-to-use interface

## iOS Notes
- Open `ios/Runner.xcworkspace` in Xcode after `flutter pub get`.
- Set bundle identifier to `www.pakvidsapp.com.pk` and enable Push Notifications + Background Modes as needed.

---

## Project Structure

- `lib/screens/home_screen.dart` – vertical feed
- `lib/widgets/video_tile.dart` – single video with controls
- `lib/services/earnings_service.dart` – earnings scaffold
- `lib/services/auth_service.dart` – auth placeholder
- `lib/services/firestore_service.dart` – Firestore wrapper
- `lib/main.dart` – app entry

---

## Privacy Policy
Link: https://pakvidz.com/privacy

---

## Live Streaming
UI placeholder is included in the profile screen. Hook this with your streaming provider (e.g., Agora, Zego, LiveKit) behind a follower-count check (>= 5000).

