import 'package:flutter/material.dart';

class EarningsService extends ChangeNotifier {
  double _balance = 0.0;
  int _coins = 0;

  double get balance => _balance;
  int get coins => _coins;

  void addCoins(int amount) {
    _coins += amount;
    _balance = _coins / 100.0; // Example conversion
    notifyListeners();
  }

  void withdraw() {
    // TODO: integrate with backend (Firebase Functions or server)
    _coins = 0;
    _balance = 0.0;
    notifyListeners();
  }
}
