class FirestoreService {
  // TODO: implement Firestore reads/writes for videos, likes, comments
}
