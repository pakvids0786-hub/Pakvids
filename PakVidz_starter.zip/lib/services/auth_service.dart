import 'package:flutter/material.dart';

class AuthService extends ChangeNotifier {
  String? _uid;
  int _followers = 0;

  String? get uid => _uid;
  int get followers => _followers;

  bool get isLoggedIn => _uid != null;

  Future<void> signInAnonymously() async {
    // TODO: integrate with FirebaseAuth
    _uid = 'demoUser';
    notifyListeners();
  }

  void setFollowers(int count) {
    _followers = count;
    notifyListeners();
  }

  bool get canGoLive => _followers >= 5000;
}
